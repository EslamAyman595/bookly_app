
import 'package:bookly_app/Features/home/presentation/views/widgets/custom_item.dart';
import 'package:flutter/material.dart';

class SearchResultLoadingIndicator extends StatelessWidget {
  const SearchResultLoadingIndicator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
        padding: EdgeInsets.zero,
        itemBuilder: (context, index) => const Padding(
          padding: EdgeInsets.symmetric(vertical: 5),
          child: CustomItem(imageUrl: '',),
        ),
        itemCount: 15,
      ),
    );
  }
}
