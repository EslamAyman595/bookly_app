class AssetsData {
  static const logo ='assets/images/Logo.png';
  static const test ='assets/images/test_image.png';
}